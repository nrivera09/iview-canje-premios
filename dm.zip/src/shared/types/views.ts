export type IView = "DM" | "SM" | "PM";
