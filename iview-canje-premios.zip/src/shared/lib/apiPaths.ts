export const API_PATHS = {
  REGALOS: "/api/Regalos/canje-regalo-vigente",
  REGALOS_IMAGEN: "/api/Regalos/imagen",
  PROMOCIONES: "/api/Promociones",
  CANJEAR: "/api/Regalos/canjear",
};
